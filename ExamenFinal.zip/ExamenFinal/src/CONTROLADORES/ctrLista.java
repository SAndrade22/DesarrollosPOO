
package CONTROLADORES;

import java.util.ArrayList;
import java.util.List;
import MODELOS.lista;
/**
 *
 * @author Usuario
 */
public class ctrLista {
    private List<lista> listaPalabras;

 
    public ctrLista() {
        this.listaPalabras = new ArrayList();
    }

    public List<lista> getListaPalabras() {
        return listaPalabras;
    }

    public void setListaPalabras(List<lista> listaPalabras) {
        this.listaPalabras = listaPalabras;
    }

    @Override
    public String toString() {
        return "ctrLista{" + "listaPalabras=" + listaPalabras + '}';
    }
    
    
    
    
}
