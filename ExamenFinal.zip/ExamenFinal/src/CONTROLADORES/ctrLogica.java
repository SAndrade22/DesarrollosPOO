
package CONTROLADORES;
import VISTAS.JUEGO;
import javax.swing.JOptionPane;
/**
 *
 * @author Usuario
 */

public class ctrLogica {
    public ctrLogica() {
        
    }
    
    
    
    public String comparar (String a, String b,String c){
        
        String X="";
        for (int i=0; i<a.length();i++) {
        if (a.charAt(i)==b.charAt(0)){
            X=X+b;
        }else{
            X=X+String.valueOf(c.charAt(i));
        }
        
        }
        
        if (X==a){
            return a;
        }else{
            return X;
        }
       
        
    }
    
      public int cuenta (String a, String b,String c){
  
        int X=0;
        for (int i=0; i<a.length();i++) {
        if (a.charAt(i)==b.charAt(0)){
            X++;
        }
        }
        String ab=comparar(a,b,c);
        if (a==ab){
            return 0;
        }else{
            return X;
        }
       
        
        
        
    }
    public boolean verifica (String a, String b,String c){
  
        boolean X=false;
        for (int i=0; i<a.length();i++) {
        if (a.charAt(i)==b.charAt(0)){
            X=true;
            
        }
        }
        
        String ab=comparar(a,b,c);
        if (a==ab){
            return false;
        }else{
            return X;
        }
       
     
        
    }
    
    public String X(String tam){
        String X="";
        for (int i=0;i<tam.length();i++){
            X=X+"X";
        } 
        return X;
    }
    
}
