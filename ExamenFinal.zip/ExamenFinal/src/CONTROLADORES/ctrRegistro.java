
package CONTROLADORES;
import MODELOS.registro;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class ctrRegistro {
    
     private List<registro> listaRegistro;
    private registro seleccionado; 
    
    public ctrRegistro(){
        listaRegistro = new ArrayList();
        seleccionado = null;
    }

    
    
    public boolean validar (int intentos){
        if (intentos<=0 || intentos>4){
            return false;
        }else{
            return true;
        }
        
    }
    
    
}
