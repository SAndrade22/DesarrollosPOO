
package MANEJOARCH;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author Usuario
 */
public class manejoCSV {
    String nombre;
    int intentos;
    int puntaje;
    List<String> palabrasConseguidas;

    public manejoCSV() {
       
    }
    
    public void crearCSV(String nombre, int intentos, int puntaje, List<String> palabrasConseguidas) throws IOException{
        this.palabrasConseguidas=palabrasConseguidas;
        FileWriter fw = new FileWriter("C:\\Users\\Usuario\\Desktop\\ExamenFinal\\src\\ARCHIVOS\\DATOS.csv",true);
        fw.append(nombre+"\n");
        fw.append(String.valueOf(intentos)+"\n");
        fw.append(String.valueOf(puntaje)+"\n");
          
        for (String i: palabrasConseguidas){

           fw.append(i+"\n");
           fw.append(';');  
        }

        fw.close();
  
    }
    
  
    
    
}
