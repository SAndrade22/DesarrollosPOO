
package MANEJOARCH;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import MODELOS.lista;
/**
 *
 * @author Usuario
 */
public class manejoTXT {
    
     private String ruta;

    public manejoTXT(String ruta) {
        this.ruta = ruta;
    }

    public List<lista> leer() {
        List<lista> leer = new ArrayList<>();
        try {
            FileReader leer2 = new FileReader(ruta);
            BufferedReader lectura = new BufferedReader(leer2);
            String lista = "";
            while(lista != null){
                lista = lectura.readLine();
                if (lista != null){
                    lista e = new lista(lista);
                    leer.add(e);
                }
            }
            lectura.close();
            leer2.close();
            return leer;
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return leer;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    @Override
    public String toString() {
        return "manejoTXT{" + "ruta=" + ruta + '}';
    }
    
    
    
    
}
