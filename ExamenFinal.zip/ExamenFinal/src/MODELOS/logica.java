
package MODELOS;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class logica {

    private int puntaje;
    private List<String> adivinadas;

    public logica() {
        this.puntaje = puntaje;
        this.adivinadas = new ArrayList();
    }

    public int getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(int puntaje) {
        this.puntaje = puntaje;
    }

    public List<String> getAdivinadas() {
        return adivinadas;
    }

    public void setAdivinadas(List<String> adivinadas) {
        this.adivinadas = adivinadas;
    }

    @Override
    public String toString() {
        return "logica{" + "puntaje=" + puntaje + ", adivinadas=" + adivinadas + '}';
    }
    
    
    
    
}
