
package MODELOS;

/**
 *
 * @author Usuario
 */
public class registro {
   private String usuario;
   private int intentos;

    public registro(String usuario, int intentos) {
        this.usuario = usuario;
        this.intentos = intentos;
    }

   
   
   
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getIntentos() {
        return intentos;
    }

    public void setIntentos(int intentos) {
        this.intentos = intentos;
    }
   
   
   
    
    
}
