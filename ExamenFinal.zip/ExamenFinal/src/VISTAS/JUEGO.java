/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VISTAS;

import CONTROLADORES.ctrLista;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import CONTROLADORES.ctrLogica;
import MANEJOARCH.manejoTXT;
import MANEJOARCH.manejoCSV;
import CONTROLADORES.ctrLista;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Usuario
 */
public class JUEGO extends javax.swing.JInternalFrame {
    private static boolean completo=false;
    private int contadorP=0;
    int c=0;
    int A;
    String nombre;
    ctrLogica logica;
    String palAux, auxPal2;
    int intentos;
    int puntuacion=0;
    private List<String> Conseguidas;
    manejoCSV csv;
    /**
     * Creates new form JUEGO
     */
    
    ctrLista cL;
    manejoTXT manejo;
    
    public JUEGO() {
       initComponents();
    }

    public JUEGO(String nombre, int intentos, String PALABRA) throws IOException {
        this.intentos=intentos;
        this.nombre=nombre;
        csv= new manejoCSV();
        Conseguidas= new ArrayList();
        manejo = new manejoTXT("C:\\Users\\Usuario\\Desktop\\ExamenFinal\\src\\ARCHIVOS\\PALABRAS.txt");
        cL=new ctrLista();
        Conseguidas.add(";");
        cL.setListaPalabras(manejo.leer());
        initComponents();
        
        INTENTOS.setText(intentos+"");
        logica= new ctrLogica();
        palAux=PALABRA;
        String a=logica.X(palAux);
        ESCONDIDA.setText(a);
        PUNTUACION.setText(puntuacion+"");
        this.c=4-intentos;
        System.out.println("C"+cL);
        A=cL.getListaPalabras().size();
        c--;
        FALLO();
    }

    public int getContadorP() {
        return contadorP;
    }

    public void setContadorP(int contadorP) {
        this.contadorP = contadorP;
    }
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AHORCADO = new javax.swing.JLabel();
        ESCONDIDA = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ENTRA = new javax.swing.JTextField();
        BOTON = new javax.swing.JButton();
        PUNTUACION = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        INTENTOS = new javax.swing.JTextField();

        AHORCADO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/I0.png"))); // NOI18N
        AHORCADO.setText("f");

        ESCONDIDA.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ESCONDIDA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ESCONDIDAActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("SOLO SE TOMARA");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("LA PRIMERA LETRA");

        ENTRA.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N

        BOTON.setText("INTENTAR");
        BOTON.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOTONActionPerformed(evt);
            }
        });

        PUNTUACION.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("PUNTUACION");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("INTENTOS");

        INTENTOS.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(AHORCADO, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(ENTRA, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(BOTON, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 21, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(ESCONDIDA)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(INTENTOS, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(PUNTUACION, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ENTRA, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BOTON, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(ESCONDIDA, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PUNTUACION, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(INTENTOS, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
            .addComponent(AHORCADO, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BOTONActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOTONActionPerformed
     
       try{
          String primero = ENTRA.getText();
          ENTRA.setText(primero.substring(0, 1));
          try{
             if (Integer.parseInt(ENTRA.getText())>0 ||Integer.parseInt(ENTRA.getText())<=0 ){
                  JOptionPane.showMessageDialog(null, "NO SE PUEDEN INGRESAR NÚMEROS");
                  ENTRA.setText("");
            }
     
          }catch(Exception excepcion){/////////////
                    auxPal2=ENTRA.getText();
                    auxPal2=auxPal2.toUpperCase();
                    ENTRA.setText(auxPal2);
                    boolean f=logica.verifica(palAux,ENTRA.getText(),ESCONDIDA.getText());//es para ver si pierde o no pierde una vida
                    int b=logica.cuenta(palAux,ENTRA.getText(),ESCONDIDA.getText());//es para contar cuantas letras encuentro
                    String a=logica.comparar(palAux,ENTRA.getText(),ESCONDIDA.getText());//cada que encuentra la palabra reemplaza a la x
                    ENTRA.setText("");
                    ESCONDIDA.setText(a);//caja de texto
                    contadorP=contadorP+b;
                    if (f==false){//si es falso llama al metodo fallo
                        System.out.println("FALLO");
                        FALLO();
                       
                        INTENTOS.setText(Integer.parseInt(INTENTOS.getText())-1+"");
                        JOptionPane.showMessageDialog(null,"NO SE ENCONTRO LA LETRA");
                    }else{
                    for (int i=0; i<b;i++){
                       puntuacion=puntuacion+1;
                    }
                    
                    PUNTUACION.setText(puntuacion+"");//puntuacion
                    JOptionPane.showMessageDialog(null,"FELICIDADES SI ESTA LA LETRA");
                        System.out.println("--"+contadorP+"==="+palAux.length());
                        
                        
                        
                    if (contadorP>=palAux.length() ){//comparar palabra completa
                       Conseguidas.add(palAux);
                        System.out.println("CONS"+Conseguidas);
                       JOptionPane.showMessageDialog(null, "PALABRA COMPLETADA");
                       
                        int seleccion = JOptionPane.showOptionDialog( null,"DESEA CONTINUAR SI/NO",
                        "Selector de opciones",JOptionPane.YES_NO_CANCEL_OPTION,
                         JOptionPane.QUESTION_MESSAGE,null,// null para icono por defecto.
                        new Object[] { "SI", "NO,GUARDAR MI PUNTAJE", },"opcion 1");

                       if (seleccion != -1){
                                 System.out.println("SELECCIONO" + (seleccion + 1));
                       }
                       if (seleccion+1==1){
                            try{
                            String d=cL.getListaPalabras().get(A-1).getPalabra();
                           
                            if (d==palAux){
                                A--;
                                palAux=cL.getListaPalabras().get(A-1).getPalabra();
                                System.out.println("NUEVO "+palAux);
                                String FN=logica.X(palAux);
                                ESCONDIDA.setText(FN);
                                contadorP=0;
                            }else{
                                palAux=cL.getListaPalabras().get(A-1).getPalabra();
                                System.out.println("NUEVO "+palAux);
                                String FN=logica.X(palAux);
                                ESCONDIDA.setText(FN);
                                contadorP=0;
                            }
                             A--;
                            }catch(Exception excepcion2){
                                JOptionPane.showMessageDialog(null, "FELICIDADES COMPLETASTE TODAS LAS PALABRAS TU PUNTAJE SE GUARDARA");
                                crearCSV();
                            }
                            System.out.println("SEGUIMOS");
                       }else if(seleccion+1==2){
                            System.out.println("NO PARAMOS");     
                            crearCSV();
                       }
                    }
                }
          }
       }catch(Exception excepcion){
          JOptionPane.showMessageDialog(null, "NO SE PUEDEN INGRESAR NÚMEROS");
       }
       String primero=ENTRA.getText();
       
       
    }//GEN-LAST:event_BOTONActionPerformed

    private void ESCONDIDAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ESCONDIDAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ESCONDIDAActionPerformed
    
    public void crearCSV() throws IOException{
        System.out.println("HOLA");
        csv.crearCSV(nombre, intentos,puntuacion , Conseguidas);
        
    }
    
    
    public void FALLO() throws IOException{
        c++;
        if (c==0){
            Icon ico=new ImageIcon(getClass().getResource("/IMAGENES/I0.png"));
            AHORCADO.setIcon(ico);
        }else if(c==1){
            Icon icono=new ImageIcon(getClass().getResource("/IMAGENES/i1.png"));
            AHORCADO.setIcon(icono);
        }else if(c==2){
            Icon icono=new ImageIcon(getClass().getResource("/IMAGENES/I2.png"));
            AHORCADO.setIcon(icono);
        }else if(c==3){
            Icon icono=new ImageIcon(getClass().getResource("/IMAGENES/i3.png"));
            AHORCADO.setIcon(icono);
        }else if(c==4){
            Icon icono=new ImageIcon(getClass().getResource("/IMAGENES/I4.png"));
            AHORCADO.setIcon(icono); 
            JOptionPane.showMessageDialog(null,"LA PALABRA ERA "+palAux);
            BOTON.setEnabled(false);
             JOptionPane.showMessageDialog(null, "TU PUNTAJE SE GUARDARA");
             crearCSV();
        }
    }

    public boolean isCompleto() {
        return completo;
    }

    public void setCompleto(boolean completo) {
        this.completo = completo;
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AHORCADO;
    private javax.swing.JButton BOTON;
    private javax.swing.JTextField ENTRA;
    public javax.swing.JTextField ESCONDIDA;
    private javax.swing.JTextField INTENTOS;
    private javax.swing.JTextField PUNTUACION;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
}
