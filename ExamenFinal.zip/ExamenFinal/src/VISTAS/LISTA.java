/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VISTAS;

import javax.swing.table.DefaultTableModel;
 import javax.swing.event.ListSelectionEvent;
 import javax.swing.event.ListSelectionListener;
import MANEJOARCH.manejoTXT;
import MODELOS.lista;
import CONTROLADORES.ctrLista;
import javax.swing.JOptionPane;
/**
 *
 * @author Usuario
 */
public class LISTA extends javax.swing.JInternalFrame {
    
    /**
     * Creates new form LISTA
     */
    boolean flag=false;
    manejoTXT manejo,manejoX;
    ctrLista cL,cE;
    String nombre,envio;
    int intentos,posicion;
    private DefaultTableModel modeloTabla;
    String palabraSelecc="BAJO";
    //boton1
    public LISTA(String nombre, int intentos) {
        
        initComponents();
        modeloTabla=(DefaultTableModel) this.TABLA.getModel();
        ///////////////////////////////////////////////////////
        manejoX = new manejoTXT("C:\\Users\\Usuario\\Desktop\\ExamenFinal\\src\\ARCHIVOS\\PALABRASX.txt");
        manejo = new manejoTXT("C:\\Users\\Usuario\\Desktop\\ExamenFinal\\src\\ARCHIVOS\\PALABRAS.txt");
        cL=new ctrLista();
        cE=new ctrLista();
        cL.setListaPalabras(manejo.leer());
        cE.setListaPalabras(manejoX.leer());
        this.nombre=nombre;
        this.intentos=intentos;
        /////////////////////////////////////////////////////////
        cargarDatos();
        TABLA.getSelectionModel().addListSelectionListener(new ListSelectionListener() {            
            public void valueChanged(ListSelectionEvent lse) {
                cargarElemento(TABLA.getSelectedRow());
                envio=palabraSelecc;
                System.out.println("Envias"+envio);   
            }
        });
        
    }
    
    //boton2
    public LISTA (){
        flag=true;
        initComponents();
        
        modeloTabla=(DefaultTableModel) this.TABLA.getModel();
        manejo = new manejoTXT("C:\\Users\\Usuario\\Desktop\\ExamenFinal\\src\\ARCHIVOS\\PALABRAS.txt");
        JugarJ.setEnabled(false);
       
        cL=new ctrLista();
        cL.setListaPalabras(manejo.leer());
        cargarDatos();
            
    }
    
    
    public void cargarDatos(){
        if (flag==true){
        modeloTabla.setRowCount(0);
        for (lista palabras : cL.getListaPalabras()) {
            String datos[] = {palabras.getPalabra()};
            modeloTabla.addRow(datos);
        }
          }else{
            modeloTabla.setRowCount(0);
            for (lista palabras :cE.getListaPalabras()) {
            String datos[] = {palabras.getPalabra()};
            modeloTabla.addRow(datos);
        }
        }
    }
    
    public void cargarElemento(int posicion){
        this.posicion = posicion;
        if(posicion >= 0){
            lista Muestra = cL.getListaPalabras().get(posicion);
            palabraSelecc=Muestra.getPalabra();           
        }else {
            palabraSelecc="BAJO";           
        }
    }
    
   
       
       
     
   

      
   
      
       
       
       

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TABLA = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        JugarJ = new javax.swing.JButton();
        CerrarJ = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setText("jLabel1");

        TABLA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PALABRAS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(TABLA);
        if (TABLA.getColumnModel().getColumnCount() > 0) {
            TABLA.getColumnModel().getColumn(0).setResizable(false);
        }

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel2.setText("PALABRAS DISPONIBLES");

        JugarJ.setText("JUGAR");
        JugarJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JugarJActionPerformed(evt);
            }
        });

        CerrarJ.setText("CERRAR");
        CerrarJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CerrarJActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(JugarJ, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(CerrarJ, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 526, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(123, 123, 123))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JugarJ, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CerrarJ, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CerrarJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CerrarJActionPerformed
        this.dispose();
    }//GEN-LAST:event_CerrarJActionPerformed

    private void JugarJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JugarJActionPerformed
        try{
             JUEGO j= new JUEGO(nombre,intentos,envio);
            PantallaPrincipal.panel.add(j);
            j.show();
        }catch(Exception excepcion){
            JOptionPane.showMessageDialog(null,"DEBES ESCOGER UNA OPCION");
        }
       
    }//GEN-LAST:event_JugarJActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CerrarJ;
    private javax.swing.JButton JugarJ;
    private javax.swing.JTable TABLA;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
