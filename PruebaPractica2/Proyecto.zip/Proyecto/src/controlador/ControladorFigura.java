/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.Figura;

/**
 *
 * @author Usuario
 */
public class ControladorFigura {
    private List<Figura> listaFigura;
    private Figura seleccionado;
    
    public ControladorFigura(){
        listaFigura=new ArrayList<>();
    }
    
    public long generarIdentificador(){
        return(listaFigura.size()>0)? listaFigura.get(listaFigura.size()-1).getIdentificador()+1:1;
    }
    
    public boolean crear(String color, double area, double perimetro){
        return listaFigura.add(new Figura(generarIdentificador(),color, area, perimetro));
    }
    
    public Figura buscar(long Identificador){
        for(Figura figura:listaFigura){
            if(figura.getIdentificador()==(Identificador)){
                seleccionado=figura;
                return figura;
            }
        }
        return null;
    }
    
    public boolean actualizar(long Identificador, String color, double area, double perimetro){
        Figura figura = buscar(Identificador);
        if (figura!=null){
            int posicion = listaFigura.indexOf(figura);
            figura.setColor(color);
            figura.setArea(area);
            figura.setPerimetro(perimetro);
            listaFigura.set(posicion, figura);
            return true;
        }
        return false;
    }
    
    public boolean eliminar(long Identificador){
        Figura figura=buscar(Identificador);
        return listaFigura.remove(figura);
    }

    public List<Figura> getListaFigura() {
        return listaFigura;
    }

    public void setListaFigura(List<Figura> listaFigura) {
        this.listaFigura = listaFigura;
    }

    public Figura getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Figura seleccionado) {
        this.seleccionado = seleccionado;
    }
    
    
}
