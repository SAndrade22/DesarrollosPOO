/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.Jefe;

public class ControladorJefe {
    private List<Jefe> listaJefe;
    private Jefe seleccionado;
    
    public ControladorJefe(){
        listaJefe=new ArrayList<>();
    }
    
    public long generarCodigo(){
        return(listaJefe.size()>0)? listaJefe.get(listaJefe.size()-1).getCodigo()+1:1;
    }
    
    public boolean crear(String Nombre, String Apellido, String direccion, String telefono){
        return listaJefe.add(new Jefe(Nombre, Apellido, generarCodigo(), direccion, telefono));
    }
    
    public Jefe buscar(long codigo){
        for(Jefe jefe:listaJefe){
            if(jefe.getCodigo()==(codigo)){
                seleccionado=jefe;
                return jefe;
            }
        }
        return null;
        
    }
    
    public boolean actualizar (String Nombre, String Apellido, long codigo, String direccion, String telefono){
        Jefe jefe = buscar(codigo);
        if (jefe!=null){
            int posicion = listaJefe.indexOf(jefe);
            jefe.setNombre(Nombre);
            jefe.setApellido(Apellido);
            jefe.setDireccion(direccion);
            jefe.setTelefono(telefono);
            listaJefe.set(posicion, jefe);
            return true;
        }
        return false;
    }
    
    public boolean eliminar(long codigo){
        Jefe jefe=buscar(codigo);
        return listaJefe.remove(jefe);
    }

    public List<Jefe> getListaJefe() {
        return listaJefe;
    }

    public void setListaJefe(List<Jefe> listaJefe) {
        this.listaJefe = listaJefe;
    }

    public Jefe getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Jefe seleccionado) {
        this.seleccionado = seleccionado;
    }
    
    
        
}
