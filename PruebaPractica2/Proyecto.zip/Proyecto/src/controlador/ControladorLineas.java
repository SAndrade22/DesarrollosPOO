/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.Lineas;

public class ControladorLineas {
    private List<Lineas> listaLineas;
    private Lineas seleccionado;
    
    public ControladorLineas(){
        listaLineas=new ArrayList<>();
    }
    
    public long generarIdentificador(){
        return(listaLineas.size()>0)? listaLineas.get(listaLineas.size()-1).getIdentificador()+1:1;
    }
    
    public boolean crear(double puntoOrigen, double puntoFinal, double longitud){
        return listaLineas.add(new Lineas(puntoOrigen, puntoFinal, longitud, generarIdentificador()));
    }
    
    public Lineas buscar(long identificador){
       for(Lineas lineas:listaLineas){
            if(lineas.getIdentificador()==(identificador)){
                seleccionado=lineas;
                return lineas;
            }
        }
        return null; 
    }
    
    public boolean actualizar (double puntoOrigen, double puntoFinal, double longitud, long identificador){
        Lineas lineas = buscar(identificador);
        if (lineas!=null){
            int posicion = listaLineas.indexOf(lineas);
            lineas.setPuntoOrigen(puntoOrigen);
            lineas.setPuntoFinal(puntoFinal);
            lineas.setLongitud(longitud);
            listaLineas.set(posicion, lineas);
            return true;
        }
        return false; 
    }
    
    public boolean eliminar(long identificador){
        Lineas lineas=buscar(identificador);
        return listaLineas.remove(lineas);
    }

    public List<Lineas> getListaLineas() {
        return listaLineas;
    }

    public void setListaLineas(List<Lineas> listaLineas) {
        this.listaLineas = listaLineas;
    }

    public Lineas getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Lineas seleccionado) {
        this.seleccionado = seleccionado;
    }
    
}
