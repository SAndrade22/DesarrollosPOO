/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.Planos;

/**
 *
 * @author Usuario
 */
public class ControladorPlanos {
    private List<Planos>listaPlanos;
    private Planos seleccionado;
    
    public ControladorPlanos(){
        listaPlanos=new ArrayList<>();
    }
    
    public long generarIdentificacion(){
        return(listaPlanos.size()>0)? listaPlanos.get(listaPlanos.size()-1).getIdentificacion()+1:1;
    }
    
    public boolean crear(String Fecha, int numArquitectos, int numFiguras){
        return listaPlanos.add(new Planos(generarIdentificacion(),Fecha, numArquitectos, numFiguras));
    }
    
    public Planos buscar(long Identificacion){
        for(Planos planos:listaPlanos){
            if(planos.getIdentificacion()==(Identificacion)){
                seleccionado=planos;
                return planos;
            }
        }
        return null;
    }
    
    public boolean actualizar(long Identificacion, String Fecha, int numArquitectos, int numFiguras){
        Planos planos = buscar(Identificacion);
        if (planos!=null){
            int posicion = listaPlanos.indexOf(planos);
            planos.setFecha(Fecha);
            planos.setNumArquitectos(numArquitectos);
            planos.setNumFiguras(numFiguras);
            listaPlanos.set(posicion, planos);
            return true;
        }
        return false;
    }
    
    public boolean eliminar(long Identificacion){
        Planos planos=buscar(Identificacion);
        return listaPlanos.remove(planos);
    }

    public List<Planos> getListaPlanos() {
        return listaPlanos;
    }

    public void setListaPlanos(List<Planos> listaPlanos) {
        this.listaPlanos = listaPlanos;
    }

    public Planos getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Planos seleccionado) {
        this.seleccionado = seleccionado;
    } 
}
