/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.Figura;
import modelo.Poligonos;

public class ControladorPoligonos {
    private List<Poligonos> listaPoligonos;
    private Poligonos seleccionado;
    
    public ControladorPoligonos(){
        listaPoligonos=new ArrayList<>();
        seleccionado=null;
    }
    
    public boolean crear(long identificador, String color, double area, double perimetro, int numLineas){
        Poligonos e=new Poligonos(identificador, color, area, perimetro, numLineas);
        return listaPoligonos.add(e);
    }
    
    public Poligonos buscar(long identificador){
        for (Poligonos poligonos : listaPoligonos) {
            if(poligonos.getIdentificador()==(identificador))
                return poligonos;
        }
        return null;
    }
    
    public boolean actualizar(long identificador, String color, double area, double perimetro, int numLineas){
        Poligonos poligonos=this.buscar(identificador);
        if(poligonos!=null){
            int posicion=listaPoligonos.indexOf(poligonos);
            poligonos.setColor(color);
            poligonos.setArea(area);
            poligonos.setPerimetro(perimetro);
            poligonos.setNumLineas(numLineas);
            listaPoligonos.set(posicion, poligonos);
            return true;
        }
        return false;
    }
    
    public boolean eliminar(long identificador){
        Poligonos poligonos=this.buscar(identificador);
        if(poligonos!=null){
            return listaPoligonos.remove(poligonos);
        }
        return false;
    }

    public List<Poligonos> getListaPoligonos() {
        return listaPoligonos;
    }

    public void setListaPoligonos(List<Poligonos> listaPoligonos) {
        this.listaPoligonos = listaPoligonos;
    }

    public Poligonos getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Poligonos seleccionado) {
        this.seleccionado = seleccionado;
    }
    
}
