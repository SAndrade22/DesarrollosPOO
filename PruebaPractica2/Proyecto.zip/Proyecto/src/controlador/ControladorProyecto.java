/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.Proyecto;

/**
 *
 * @author Usuario
 */
public class ControladorProyecto {
    private List<Proyecto> listaProyecto;
    private Proyecto seleccionado;
    
    public ControladorProyecto(){
        listaProyecto=new ArrayList<>();
    }
    public long generarCodigo(){
        return(listaProyecto.size()>0)? listaProyecto.get(listaProyecto.size()-1).getCodigo()+1:1;
    }
    public boolean crear(String Nombre){
        return listaProyecto.add(new Proyecto(generarCodigo(),Nombre));
    }
    
    public Proyecto buscar(long codigo){
       for(Proyecto proyecto:listaProyecto){
            if(proyecto.getCodigo()==(codigo)){
                seleccionado=proyecto;
                return proyecto;
            }
        }
        return null; 
    }
    
    public boolean actualizar(long codigo, String Nombre){
        Proyecto proyecto = buscar(codigo);
        if (proyecto!=null){
            int posicion = listaProyecto.indexOf(proyecto);
            proyecto.setNombre(Nombre);
            
            return true;
        }
        return false;
    }
    public boolean eliminar(long codigo){
        Proyecto proyecto=buscar(codigo);
        return listaProyecto.remove(proyecto);
    }

    public List<Proyecto> getListaProyecto() {
        return listaProyecto;
    }

    public void setListaProyecto(List<Proyecto> listaProyecto) {
        this.listaProyecto = listaProyecto;
    }

    public Proyecto getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Proyecto seleccionado) {
        this.seleccionado = seleccionado;
    }
}
