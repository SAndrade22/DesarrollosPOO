/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Figura {
    private long identificador;
    private String color;
    private double area;
    private double perimetro;

    public Figura(long identificador, String color, double area, double perimetro) {
        this.identificador = identificador;
        this.color = color;
        this.area = area;
        this.perimetro = perimetro;
    }

    public long getIdentificador() {
        return identificador;
    }

    public void setIdentificador(long identificador) {
        this.identificador = identificador;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public double getPerimetro() {
        return perimetro;
    }

    public void setPerimetro(double perimetro) {
        this.perimetro = perimetro;
    }

    @Override
    public String toString() {
        return "Figura{" + "identificador=" + identificador + ", color=" + color + ", area=" + area + ", perimetro=" + perimetro + '}';
    }
}
