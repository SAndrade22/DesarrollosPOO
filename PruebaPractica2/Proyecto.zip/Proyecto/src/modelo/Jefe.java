/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Jefe {
    private String id;
    private String Nombre;
    private String Apellido;
    private long codigo;
    private String direccion;
    private String telefono;

    public Jefe(String Nombre, String Apellido, long codigo, String direccion, String telefono) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.codigo = codigo;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public long getCodigo() {
        return codigo;
    }

    public void setCodigo(long codigo) {
        this.codigo = codigo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Jefe{" + "Nombre=" + Nombre + ", Apellido=" + Apellido + ", codigo=" + codigo + ", direccion=" + direccion + ", telefono=" + telefono + '}';
    }
}
