/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Lineas {
    private double puntoOrigen;
    private double puntoFinal;
    private double longitud;
    private long identificador;

    public Lineas(double puntoOrigen, double puntoFinal, double longitud, long identificador) {
        this.puntoOrigen = puntoOrigen;
        this.puntoFinal = puntoFinal;
        this.longitud = longitud;
        this.identificador = identificador;
    }

    
    public double getPuntoOrigen() {
        return puntoOrigen;
    }

    public void setPuntoOrigen(double puntoOrigen) {
        this.puntoOrigen = puntoOrigen;
    }

    public double getPuntoFinal() {
        return puntoFinal;
    }

    public void setPuntoFinal(double puntoFinal) {
        this.puntoFinal = puntoFinal;
    }

    public double getLongitud() {
        return longitud;
    }

    public void setLongitud(double longitud) {
        this.longitud = longitud;
    }

    public long getIdentificador() {
        return identificador;
    }

    public void setIdentificador(long identificador) {
        this.identificador = identificador;
    }

    @Override
    public String toString() {
        return "Lineas{" + "puntoOrigen=" + puntoOrigen + ", puntoFinal=" + puntoFinal + ", longitud=" + longitud + ", identificador=" + identificador + '}';
    }
    
    
}
