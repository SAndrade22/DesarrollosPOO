/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Planos {
    private long Identificacion;
    private String Fecha;
    private int numArquitectos;
    private int numFiguras;

    public Planos(long Identificacion, String Fecha, int numArquitectos, int numFiguras) {
        this.Identificacion = Identificacion;
        this.Fecha = Fecha;
        this.numArquitectos = numArquitectos;
        this.numFiguras = numFiguras;
    }

    public long getIdentificacion() {
        return Identificacion;
    }

    public void setIdentificacion(long Identificacion) {
        this.Identificacion = Identificacion;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public int getNumArquitectos() {
        return numArquitectos;
    }

    public void setNumArquitectos(int arquitectos) {
        this.numArquitectos = numArquitectos;
    }

    public int getNumFiguras() {
        return numFiguras;
    }

    public void setNumFiguras(int figuras) {
        this.numFiguras = numFiguras;
    }

    @Override
    public String toString() {
        return "Planos{" + "Identificacion=" + Identificacion + ", Fecha=" + Fecha + ", numArquitectos=" + numArquitectos + ", numFiguras=" + numFiguras + '}';
    }

    
    
}
