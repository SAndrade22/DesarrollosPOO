/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Poligonos extends Figura{
    private int numLineas;
    
    public Poligonos( long identificador, String color, double area, double perimetro) {
        super(identificador, color, area, perimetro); //super indica que datos vienen del 
    }
    
    public Poligonos( long identificador, String color, double area, double perimetro, int numLineas) {
        super(identificador, color, area, perimetro); //super indica que datos vienen del 
        this.numLineas = numLineas; //agregamos sueldo bruto a un constructor aparte
    }

    public int getNumLineas() {
        return numLineas;
    }

    public void setNumLineas(int numLineas) {
        this.numLineas = numLineas;
    }

    @Override
    public String toString() {
        return "Poligonos{" + "numLineas=" + numLineas + '}';
    }
    
    
}
