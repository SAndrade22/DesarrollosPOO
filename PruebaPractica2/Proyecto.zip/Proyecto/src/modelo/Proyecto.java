/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Proyecto {
    private long codigo;
    private String Nombre;

    public Proyecto(long codigo, String Nombre) {
        this.codigo = codigo;
        this.Nombre = Nombre;
    }

    public long getCodigo() {
        return codigo;
    }

    public void setCodigo(long codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    @Override
    public String toString() {
        return "Proyecto{" + "codigo=" + codigo + ", Nombre=" + Nombre + '}';
    }
}
