/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import controlador.ControladorPlanos;
import java.util.Scanner;
import modelo.Planos;

public class VistaPlanos {
    public Scanner teclado;
    private ControladorPlanos controladorPlanos;
    
    public VistaPlanos(ControladorPlanos controladorPlanos){
        teclado=new Scanner(System.in);
        this.controladorPlanos=controladorPlanos;
    }
    
    public void menu(){
        int opcion=0;
        do{
            System.out.println("1. Crear \n 2. Actualizar \n 3. Buscar \n 4. Eliminar \n 5. Listar \n 6. Sair");
            opcion=teclado.nextInt();
            switch(opcion){
                case 1:this.crear(); break;
                case 2:this.actualizar(); break;
                case 3:this.buscar(); break;
                case 4:this.eliminar(); break;
                case 5:this.listar(); break;
            }
        }while(true);
    }
    
    public void crear()
    {
        System.out.println("Ingrese: \n Fecha");
        String Fecha=teclado.next();
        System.out.println("Numero de Arquitectos");
        int numArqui=teclado.nextInt();
        System.out.println("Numero de Figuras");
        int numFiguras=teclado.nextInt();
        System.out.println("Res: "+ controladorPlanos.crear(Fecha, numArqui, numFiguras));
    }
    
    public void actualizar(){
        System.out.println("Ingrese: \n Identificacion");
        long identificacion=teclado.nextLong();
        System.out.println("Ingrese: \n Fecha");
        String fecha=teclado.next();
        System.out.println("Ingrese: \n Numero de Arquitectos");
        int numArqui=teclado.nextInt();
        System.out.println("Ingrese: \n Numero de Figuras");
        int numFiguras=teclado.nextInt();
        System.out.println("Res: "+controladorPlanos.actualizar(identificacion, fecha, numArqui, numFiguras));
    }
    
    public void buscar(){
        System.out.println("Ingrese: \n identificacion de los planos");
        long identificacion=teclado.nextLong();
        System.out.println(controladorPlanos.buscar(identificacion));
    }
    
    public void eliminar(){
        this.buscar();
        System.out.println("Res: "+controladorPlanos.eliminar(controladorPlanos.getSeleccionado().getIdentificacion()));
    }
    
    public void listar(){
        for(Planos planos : controladorPlanos.getListaPlanos()){
            System.out.println(planos);
        }
    }
}
