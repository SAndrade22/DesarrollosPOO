/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import controlador.ControladorFigura;
import java.util.Scanner;
import modelo.Figura;

public class vistaFigura {
    public Scanner teclado;
    private ControladorFigura controladorFigura;
    public vistaFigura(ControladorFigura controladorFigura){
        teclado=new Scanner(System.in);
        this.controladorFigura=controladorFigura;
    }
    
    public void menu(){
        int opcion=0;
        do{
            System.out.println("1. Crear \n 2. Actualizar \n 3. Buscar \n 4. Eliminar \n 5. Listar \n 6. Sair");
            opcion=teclado.nextInt();
            switch(opcion){
                case 1:this.crear(); break;
                case 2:this.actualizar(); break;
                case 3:this.buscar(); break;
                case 4:this.eliminar(); break;
                case 5:this.listar(); break;
            }
        }while(true);
    }
    
    public void crear()
    {
        System.out.println("Ingrese: \n Color");
        String color=teclado.next();
        System.out.println("Ingrese: \n Area");
        double area=teclado.nextDouble();
        System.out.println("Ingrese: \n Perimetro");
        double perimetro=teclado.nextDouble();
        System.out.println("Res: "+ controladorFigura.crear(color, area, perimetro));
    }
    
    public void actualizar(){
        System.out.println("Ingrese: \n Indentificador");
        long identificador=teclado.nextLong();
        System.out.println("Ingrese: \n Color");
        String color=teclado.next();
        System.out.println("Ingrese: \n Area");
        double area=teclado.nextDouble();
        System.out.println("Ingrese: \n Perimetro");
        double perimetro=teclado.nextDouble();
        System.out.println("Res: "+controladorFigura.actualizar(identificador, color, area, perimetro));
    }
    
    public void buscar(){
        System.out.println("Ingrese: \n Codigo");
        long codigo=teclado.nextLong();
        System.out.println(controladorFigura.buscar(codigo));
    }
    
    public void eliminar(){
        this.buscar();
        System.out.println("Res: "+controladorFigura.eliminar(controladorFigura.getSeleccionado().getIdentificador()));
    }
    
    public void listar(){
        for(Figura figura : controladorFigura.getListaFigura()){
            System.out.println(figura);
        }
    }
}
