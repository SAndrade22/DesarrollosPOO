/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.util.Scanner;
import controlador.ControladorFigura;
import controlador.ControladorJefe;
import controlador.ControladorLineas;
import controlador.ControladorPlanos;
import controlador.ControladorPoligonos;
import controlador.ControladorProyecto;

public class vistaGeneral {
    public Scanner teclado;
    public VistaPlanos vistaPlanos;
    public ControladorPlanos controladorPlanos;
    public vistaFigura vistaFigura;
    public ControladorFigura controladorFigura;
    public vistaJefe vistaJefe;
    public ControladorJefe controladorJefe;
    public vistaLineas vistaLineas;
    public ControladorLineas controladorLineas;
    public vistaPoligonos vistaPoligonos;
    public ControladorPoligonos controladorPoligonos;
    public vistaProyecto vistaProyecto;
    public ControladorProyecto controladorProyecto;
    
    public vistaGeneral(){
        teclado = new Scanner(System.in);
        controladorPlanos=new ControladorPlanos(); 
        controladorFigura=new ControladorFigura();
        controladorJefe=new ControladorJefe();
        controladorLineas=new ControladorLineas();
        controladorPoligonos=new ControladorPoligonos();
        controladorProyecto=new ControladorProyecto();
        vistaPoligonos=new vistaPoligonos();
        vistaPlanos=new VistaPlanos(controladorPlanos);
        vistaFigura=new vistaFigura(controladorFigura);
        vistaJefe=new vistaJefe(controladorJefe);
        vistaLineas=new vistaLineas(controladorLineas);
      
        vistaProyecto=new vistaProyecto(controladorProyecto); 
    }
    
    public void menu(){
        int op=0;
        do{
            System.out.println("Seleccionar una opción");
            System.out.println("1.Jefe de Proyecto");
            System.out.println("2.Proyecto");
            System.out.println("3.Planos");
            System.out.println("4.Figura");
            System.out.println("5.Poligonos");
            System.out.println("6.Lineas");
            op=teclado.nextInt();
            switch(op){
                case 1:vistaJefe.menu();break;
                case 2:vistaProyecto.menu();break;
                case 3:vistaPlanos.menu();break;
                case 4:vistaFigura.menu();break;
                case 5:vistaPoligonos.menu();break;
                case 6:vistaLineas.menu();break;
            }
        }while(op<7);
    }
}
