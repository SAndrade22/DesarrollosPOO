/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import controlador.ControladorJefe;
import java.util.Scanner;
import modelo.Jefe;

public class vistaJefe {
    public Scanner teclado;
    private ControladorJefe controladorJefe;
    public vistaJefe(ControladorJefe controladorJefe){
        teclado=new Scanner(System.in);
        this.controladorJefe=controladorJefe;
    }
    
    public void menu(){
        int opcion=0;
        do{
            System.out.println("1. Crear \n 2. Actualizar \n 3. Buscar \n 4. Eliminar \n 5. Listar \n 6. Sair");
            opcion=teclado.nextInt();
            switch(opcion){
                case 1:this.crear(); break;
                case 2:this.actualizar(); break;
                case 3:this.buscar(); break;
                case 4:this.eliminar(); break;
                case 5:this.listar(); break;
            }
        }while(true);
    }
    
    public void crear()
    {
        System.out.println("Ingrese: \n Nombre");
        String Nombre=teclado.next();
        System.out.println("Apellido");
        String Apellido=teclado.next();
        System.out.println("Direccion");
        String Direccion=teclado.next();
        System.out.println("Telefono");
        String telefono=teclado.next();
        System.out.println("Res: "+ controladorJefe.crear(Nombre,Apellido, Direccion, telefono));
    }
    
    public void actualizar(){
        System.out.println("Ingrese: \n Nombre");
        String Nombre=teclado.next();
        System.out.println("Ingrese: \n Apellido");
        String Apellido=teclado.next();
        System.out.println("Ingrese: \n Codigo");
        long codigo=teclado.nextLong();
        System.out.println("Ingrese: \n Direccion");
        String Direccion=teclado.next();
        System.out.println("Ingrese: \n Telefono");
        String telefono=teclado.next();
        System.out.println("Res: "+controladorJefe.actualizar(Nombre, Apellido, codigo, Direccion,  telefono));
    }
    
    public void buscar(){
        System.out.println("Ingrese: \n Codigo");
        long codigo=teclado.nextLong();
        System.out.println(controladorJefe.buscar(codigo));
    }
    
    public void eliminar(){
        this.buscar();
        System.out.println("Res: "+controladorJefe.eliminar(controladorJefe.getSeleccionado().getCodigo()));
    }
    
    public void listar(){
        for(Jefe jefe : controladorJefe.getListaJefe()){
            System.out.println(jefe);
        }
    }
}
