/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.util.Scanner;
import controlador.ControladorLineas;
import modelo.Lineas;

public class vistaLineas {
    public Scanner teclado;
    private ControladorLineas controladorLineas;
    
    public vistaLineas(ControladorLineas controladorLineas){
        teclado=new Scanner(System.in);
        this.controladorLineas=controladorLineas;
    }
    
    public void menu(){
        int opcion=0;
        do{
            System.out.println("1. Crear \n 2. Actualizar \n 3. Buscar \n 4. Eliminar \n 5. Listar \n 6. Sair");
            opcion=teclado.nextInt();
            switch(opcion){
                case 1:this.crear(); break;
                case 2:this.actualizar(); break;
                case 3:this.buscar(); break;
                case 4:this.eliminar(); break;
                case 5:this.listar(); break;
            }
        }while(true);
    }
    
    public double crear()
    {
        System.out.println("Ingrese: \n Punto de Origen");
        double puntoOrigen=teclado.nextDouble();
        System.out.println("Ingrese: \n Punto del Final");
        double puntoFinal=teclado.nextDouble();
        double longitud=puntoFinal-puntoOrigen;
        System.out.println("La longitud es: " + longitud);
        System.out.println("Res: "+ controladorLineas.crear(puntoOrigen, puntoFinal, longitud));
        return longitud;
    }
    
    public void actualizar(){
        System.out.println("Ingrese: \n Identificador");
        long identificador=teclado.nextLong();
        System.out.println("Ingrese: \n punto de Origen");
        double puntoOrigen=teclado.nextDouble();
        System.out.println("Ingrese: \n Punto del final");
        double puntoFinal=teclado.nextDouble();;
        System.out.println("Ingrese: \n Longitud");
        double longitud=teclado.nextDouble();
        System.out.println("Res: "+controladorLineas.actualizar(puntoOrigen, puntoFinal, longitud, identificador ));
    }
    
    public void buscar(){
        System.out.println("Ingrese: \n identificador de las Lineas");
        long identificador=teclado.nextLong();
        System.out.println(controladorLineas.buscar(identificador));
    }   
    
    public void eliminar(){
        this.buscar();
        System.out.println("Res: "+controladorLineas.eliminar(controladorLineas.getSeleccionado().getIdentificador()));
    }
    
    public void listar(){
        for(Lineas lineas : controladorLineas.getListaLineas()){
            System.out.println(lineas);
        }
    }
}
