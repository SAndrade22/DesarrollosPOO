/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import controlador.ControladorPoligonos;
import java.util.Scanner;
import modelo.Poligonos;
import vista.vistaLineas;
import controlador.ControladorLineas;

public class vistaPoligonos {
    private ControladorPoligonos controladorPoligonos;
    private final Scanner teclado;
    private ControladorLineas controladorLineas;
    
    public vistaPoligonos(){
        controladorPoligonos=new ControladorPoligonos();
        teclado=new Scanner(System.in);
    }
    
    public void menu(){
        int opcion=0;
        do{
            System.out.println("1. Crear \n 2. Actualizar \n 3. Buscar \n 4. Eliminar \n 5. Listar \n 6. Sair");
            opcion=teclado.nextInt();
            switch(opcion){
                case 1:this.crear(); break;
                case 2:this.actualizar(); break;
                case 3:this.buscar(); break;
                case 4:this.eliminar(); break;
                case 5:this.listar(); break;
            }
        }while(true);
    }
    
    public double perimetroPoligono(int numLineas)
    {
        double lado;
        double perimetro = 0;
        for(int i = 1; i <= numLineas; i++)
        {
            System.out.println("Ingrese el lado " + i + ": ");
            System.out.println("Ingrese: \n Punto de Origen");
            double puntoOrigen=teclado.nextDouble();
            System.out.println("Ingrese: \n Punto del Final");
            double puntoFinal=teclado.nextDouble();
            double longitud=puntoFinal-puntoOrigen;
        
            perimetro = perimetro + longitud;
        }
        return perimetro;
    }
    
    public void crear(){
        System.out.println("Ingresar identificador");
        long identificador=teclado.nextLong();
        System.out.println("Ingresar color");
        String color=teclado.next();
        System.out.println("Ingresar Numero de lineas");
        int numLineas=teclado.nextInt();
        System.out.println("Ingresar area");
        double area=teclado.nextDouble();
        double perimetro=perimetroPoligono(numLineas);
        System.out.println("El perimetro es: " + perimetro);
        System.out.println("Resultado "+controladorPoligonos.crear(identificador,color, area, perimetro, numLineas));

    }
    
    public void actualizar(){
        System.out.println("Ingrese: \n Identificador");
        long identificador=teclado.nextLong();
        System.out.println("Ingrese: \n Color");
        String color=teclado.next();
        System.out.println("Ingrese: \n Area");
        double area=teclado.nextDouble();
        System.out.println("Ingrese: \n Perimetro");
        double perimetro=teclado.nextDouble();
        System.out.println("Numero de Lineas");
        int numLineas=teclado.nextInt();
        System.out.println("Res: "+controladorPoligonos.actualizar(identificador, color, area, perimetro, numLineas));
    }
    
    public void buscar(){
        System.out.println("Ingrese: \n Identificador");
        long identificador=teclado.nextLong();
        System.out.println(controladorPoligonos.buscar(identificador));
    }
    
    public void eliminar(){
        this.buscar();
        System.out.println("Res: "+controladorPoligonos.eliminar(controladorPoligonos.getSeleccionado().getIdentificador()));
    }
    
    public void listar(){
        for(Poligonos poligonos : controladorPoligonos.getListaPoligonos()){
            System.out.println(poligonos);
        }
    }
}
