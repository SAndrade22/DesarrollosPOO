/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PanelFiguras;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import javax.accessibility.AccessibleContext;
import javax.swing.event.EventListenerList;
import javax.swing.plaf.ComponentUI;


public class panelPrincipal extends JPanel {
    private Figuras figuras;
    private int tipoFigura;
    
     public panelPrincipal(){
        setBounds(0, 0, 500, 500);
        figuras= new Figuras(0, 0, 200, 200);
        tipoFigura = 0;
    }
     
    @Override
    public void paint(Graphics lienzo){
        
        lienzo.setColor(Color.RED);
        switch (tipoFigura){
            case 1:
                lienzo.drawLine(figuras.getX(), figuras.getY(), figuras.getAncho(), figuras.getAlto());
                break;
            case 2:
                lienzo.drawRect(figuras.getX(), figuras.getY(), figuras.getAncho(), figuras.getAlto());
                break;
            case 3:
                lienzo.drawRoundRect(20, 50, 300, 200, 50, 30);
                break;
            case 4:
                lienzo.drawOval(figuras.getX(), figuras.getY(), figuras.getAncho(), figuras.getAlto());
                break;
        }
    }

    public Figuras getFiguras() {
        return figuras;
    }

    public void setFiguras(Figuras figuras) {
        this.figuras = figuras;
    }

    public int getTipoFigura() {
        return tipoFigura;
    }

    public void setTipoFigura(int tipoFigura) {
        this.tipoFigura = tipoFigura;
    }

    public ComponentUI getUi() {
        return ui;
    }

    public void setUi(ComponentUI ui) {
        this.ui = ui;
    }

    public EventListenerList getListenerList() {
        return listenerList;
    }

    public void setListenerList(EventListenerList listenerList) {
        this.listenerList = listenerList;
    }

    public AccessibleContext getAccessibleContext() {
        return accessibleContext;
    }

    public void setAccessibleContext(AccessibleContext accessibleContext) {
        this.accessibleContext = accessibleContext;
    }
    
}
