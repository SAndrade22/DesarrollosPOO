/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PanelFiguras;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class vtn extends JFrame{
    private panelPrincipal panelPrincipal;
    private JPanel panelSeleccion;
    private JButton btnLinea;
    private JButton btnCuadrado;
    private JButton btnRectangulo;
    private JButton btnCirculo;
    
    public vtn(){
        super();
        setTitle("Graficos");
        setBounds(0, 0, 1000, 1000);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponentes();
    }
    public void initComponentes(){
        panelSeleccion= new JPanel();
        panelPrincipal = new panelPrincipal();
        
        btnLinea = new JButton("Línea");
        btnLinea.setBounds(0, 0, 100, 100);
        panelSeleccion.add(btnLinea);
        
        btnRectangulo = new JButton("Rectángulo");
        btnRectangulo.setBounds(0, 0, 100, 100);
        panelSeleccion.add(btnRectangulo);
        
        btnCirculo = new JButton("CÍrculo");
        btnCirculo.setBounds(0, 0, 100, 100);
        panelSeleccion.add(btnCirculo);
        
        btnCuadrado = new JButton("Cuadrado");
        btnCuadrado.setBounds(0, 0, 100, 100);
        panelSeleccion.add(btnCuadrado);
        
        
        add(panelSeleccion, BorderLayout.NORTH);
        add(panelPrincipal, BorderLayout.CENTER);
        
        btnLinea.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                panelPrincipal.setTipoFigura(1);
                panelPrincipal.getFiguras().setX(300);
                panelPrincipal.getFiguras().setY(1000);
                panelPrincipal.getFiguras().setAncho(200);
                panelPrincipal.getFiguras().setAlto(200);
                panelPrincipal.repaint();
            }
        });
        
        btnRectangulo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                panelPrincipal.setTipoFigura(2);
                panelPrincipal.getFiguras().setX(400);
                panelPrincipal.getFiguras().setY(100);
                panelPrincipal.getFiguras().setAncho(500);
                panelPrincipal.getFiguras().setAlto(200);
                panelPrincipal.repaint();
            }
        });
        
        btnCirculo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                panelPrincipal.setTipoFigura(4);
                panelPrincipal.getFiguras().setX(600);
                panelPrincipal.getFiguras().setY(600);
                panelPrincipal.getFiguras().setAncho(300);
                panelPrincipal.getFiguras().setAlto(300);
                panelPrincipal.repaint();
            }
        });
        
        btnCuadrado.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                panelPrincipal.setTipoFigura(3);
                panelPrincipal.getFiguras().setX(300);
                panelPrincipal.getFiguras().setY(500);
                panelPrincipal.getFiguras().setAncho(3200);
                panelPrincipal.getFiguras().setAlto(300);
                panelPrincipal.repaint();
            }
        });
    }
}
