/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evento;

import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;

public class ventanaRaton extends JFrame {
    public raton panelRaton;
    public ventanaRaton(){
        setTitle("Laberinto");
        setBounds(0,0,500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initcomponents(); //siempre
        
    }
    public void initcomponents(){
        panelRaton=new raton();
        setContentPane(panelRaton);
        panelRaton.repaint();
        //addMouseListener(panelRaton); para el clickeo y pression del raton
        addMouseMotionListener((MouseMotionListener) panelRaton); //esto para el movimiento del rator
    }
}
