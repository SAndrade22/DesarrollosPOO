/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juanandrade_calculadora;

/**
 *
 * @author Usuario
 */
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import javax.swing.JTextArea;


public class Contenido extends JFrame implements ActionListener {
    private JButton boton1,boton2,boton3,boton4,boton5,boton6; 
    private JButton boton[]=new JButton[10];
    private int valor1,num1,num2;
    private JTextField resultado;
    private char opcion; 
    
    
    public Contenido(){
        super();
        setLayout(new BorderLayout());
        JPanel panel=new JPanel();
        panel.setLayout(new GridLayout(4,4));
        
        for(int i=0;i<=9;i++){
            boton[i]=new JButton(i+"");
            panel.add(boton[i]);
            boton[i].addActionListener(this);
        }
        
        boton1=new JButton(" + (suma)");
        panel.add(boton1);
        boton1.addActionListener(this);
 
        boton2=new JButton(" - (resta)");
        panel.add(boton2);
        boton2.addActionListener(this);
        
        boton3=new JButton(" / (dividor) ");
        panel.add(boton3);
 
        boton4=new JButton(" * (multiplicador)");
        panel.add(boton4);
        boton4.addActionListener(this);

        boton5=new JButton(" = (resultado)");
        panel.add(boton5);
        boton5.addActionListener(this);
 
        boton6=new JButton(" C (Limpiar)");
        panel.add(boton6);
        boton6.addActionListener(this);
 
        resultado=new JTextField(10);
        add(panel,BorderLayout.CENTER);
        add(resultado,BorderLayout.NORTH);
        setSize(700,600);
    }
    
        @Override
        public void actionPerformed(ActionEvent ae){
        JButton botonPulsado=(JButton)ae.getSource();
        
    if(botonPulsado == boton6){
        valor1=num1=num2=0;
        resultado.setText(" ");
        
    }else if(botonPulsado==boton5){
        num2=Integer.parseInt(resultado.getText());
        operaciones();
  	resultado.setText("" + valor1);
        
    }else
        {
 	boolean seleccion=false;
 	if(botonPulsado==boton1){ 
            opcion= '+';
            seleccion=true;
	}
 	if(botonPulsado==boton2){ 
            opcion= '-';
            seleccion=true;
        }
	if(botonPulsado==boton4){ 
            opcion= '*';
            seleccion=true;
        }
        if(botonPulsado==boton3){ 
            opcion= '/';
            seleccion=true;
        }
	if(seleccion==false){
            for(int i=0;i<10;i++){
		if(botonPulsado==boton[i]){
                    String texto=resultado.getText();
                    texto+=i;
                    resultado.setText(texto);
                    setSize(400,400);
		}
            }
	}else{
            num1=Integer.parseInt(resultado.getText());
            resultado.setText("");
        }
    }
}
    public int operaciones(){
        switch(opcion){
            case '+':   
                valor1= num1+num2;  
                break;
            case '-':    
                valor1 = num1-num2;   
                break;
            case '/':    
                valor1 = num1/num2; 
                break;
            case '*':    
                valor1 =num1*num2; 
                break;
        }   
        return 0;
    }
}


